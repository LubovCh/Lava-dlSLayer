# Copyright (C) 2023 Intel Corporation
# SPDX-License-Identifier:  BSD-3-Clause


from .bdd100k import BDD


__all__ = ['BDD']
